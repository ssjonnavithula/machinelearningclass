#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  2 09:02:51 2023

@author: seshajonnavithula
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("Data/P2/smalltrain.csv")##masterfile

filename = input("training file name: ")
train = pd.read_csv(filename)
filename = input("training file name: ")
test = pd.read_csv(filename)
col = np.array(["Test1", "Test2", "Pass"]) 
#train = train[col].to_numpy()
#test = test[col].to_numpy()
x0 = train["Test1"].to_numpy()
x1 = train["Test2"].to_numpy()
y = train["Pass"].to_numpy()

k=3
tp = 0
tn = 0
fp = 0
fn = 0

def distance(train,test1,test2,x0,x1):
    d1 = (x0 - test1)**2
    d2 = (x1 - test2)**2
    distances = (d1 + d2)**0.5
    return distances
for i in range(len(test)):
    val1 = x0[i]
    val2 = x1[i]
    
    
    distances = distance(train,val1,val2,x0,x1)
    #distances = distances.reshape(len(distances),1)
    
    train["distance"] = distances
    #train = np.concatenate([train, distances], axis = 1)
    #train = train[np.argsort(train[:, 3])]
    dftrain = train.sort_values("distance", ascending = True)
    dftrain.reset_index(inplace=True)

    cappass = 0 
    capfail = 0 
    for j in range(k):
        if dftrain.loc[j].at["Pass"] == 1:
            cappass += 1
        else:
            capfail += 1
    #predict if test point passed or failed QC based on its neighbors
    '''
    print(cappass)
    print(capfail)
    '''
    if cappass > capfail:
        predict = 1
    else:
        predict = 0
    #compare prediction and actual values and add 1 to the correct value for the confusion matrix
    if predict == y[i]:
        if predict == 1:
            tp += 1
        else:
            tn += 1 
    else:
        if predict == 1:
            fp += 1 
        else:
            fn += 1 
print("FP: " + str(fp))
print("FN: " + str(fn))
print("TP: " + str(tp))
print("TN: " + str(tn))
acc = (tp+tn)/(tp+tn+fp+fn)
prec = tp/(tp+fp)
rec = tp/(tp+fn)
f1 = 2*(1/((1/prec)+(1/rec)))


print("Accuracy: " + str(acc))
print("Precision: " + str(prec))
print("Recall: " + str(rec))
print("f1 Score: " + str(f1))

#Have to compute distances to all points
#Have to add distances to a table
#Sort table
#Find points that are lowest distance away - number of pionts = k
#Classify this point in the same way
#Test different k vals for each fold
#Find optimal k val for most folds
#use that k val on total training data
#make confusion matrix on testing data after applying the k



#ask user for training and test 
#for each val in test, compute distances to all other points, sort the table, predict for different k values (how many of nearest points to consider), record number of incorrect predictions for the test with different ks
'''
train = input("training file name: ")
filename = "Data/P2/" + train + ".csv"
dftrain = pd.read_csv(filename)
test = input("testing file name: ")
filename = "Data/P2/" + test + ".csv"
dftest = pd.read_csv(filename)

test1 = dftrain["Test1"].to_numpy()
test2 = dftrain["Test2"].to_numpy()
Pass = dftrain["Pass"].to_numpy()

accuracy = pd.DataFrame()


for i in range(0,len(test1)):
    testingtest1 = test1[i]
    testingtest2 = test2[i]
    
    dist1 = (test1 - testingtest1)**2
    dist2 = (test2 - testingtest2)**2
    distarray = (dist1+dist2)**0.5
    dftrain["distance"] = distarray
    
    
    dftrain = dftrain.sort_values("distance", ascending = True)
    Pass = dftrain["Pass"].to_numpy()
    
    print(dftrain.head(26))
    passed = np.array([])
    mysum = 0
    for i in range(1,26,2):
        for k in range(0,i):
            #print("k: " + str(k))
            #print("pass" + str(Pass[k]))
            mysum += Pass[k]
        acc = (mysum)/i
        mysum = 0
        if acc>=0.5: 
            passed = np.append(passed,1)
        else:
            passed = np.append(passed,0)
    
    print(passed)
'''    